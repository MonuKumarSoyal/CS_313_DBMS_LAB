-- inserting values into book table 

insert into book values (1, "Book_1", "Historical fiction", "author_1");
insert into book values (2, "Book_2", "Mystery", "author_2");
insert into book values (3, "Book_1", "Adventure", "author_3");
insert into book values (4, "Book_3", "Mystery", "author_1");
insert into book values (5, "Book_4", "Classics", "author_4");
insert into book values (6, "Book_5", "Adventure", "author_2");


-- inserting values into student table

insert into student values (1, "student_1", "Comp. Sci.", 2021, "Spring");
insert into student values (2, "student_2", "Electrical", 2020, "Spring");
insert into student values (3, "student_3", "Mechanical", 2022, "Fall");
insert into student values (4, "student_1", "Comp. Sci.", 2019, "Spring");
insert into student values (5, "student_4", "Mechanical", 2021, "Fall");
insert into student values (6, "student_3", "Civil", 2020, "Spring");

-- Insertig values into issue table

insert into issue values (1, 1, "2022.2.12", "2022.2.13");
insert into issue values (2, 5, "2022.3.2", "2022.3.10");
insert into issue values (4, 2, "2022.4.16", "2022.4.19");
insert into issue values (5, 3, "2022.3.22", "2022.3.22");
insert into issue values (4, 2, "2022.2.5", "2022.2.5");
insert into issue values (5, 4, "2022.2.22", "2022.3.3");
insert into issue values (3, 1, "2022.5.17", "2022.5.25");
insert into issue values (6, 4, "2022.5.16", "2022.5.22");
insert into issue values (3, 6, "2022.2.22", "2022.3.3");




